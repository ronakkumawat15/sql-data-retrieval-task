# SQL Project: Basic Data Retrieval & Filtering

## Description
This project demonstrates fundamental SQL skills including data retrieval, filtering, sorting, and validation.

## Objective
To extract insights from an employee database using SQL.

## Tools Used
- MySQL / PostgreSQL

## Dataset
Employees table

## Sample Query
SELECT first_name, salary
FROM employees
WHERE department = 'Sales'
AND salary > 50000;
