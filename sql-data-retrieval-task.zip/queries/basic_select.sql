-- Select specific columns
SELECT first_name, last_name FROM employees;

-- Calculated column
SELECT first_name, salary, salary * 1.1 AS increased_salary FROM employees;
