SELECT COUNT(*) AS total_filtered,
MIN(salary) AS min_salary,
MAX(hire_date) AS latest_hire
FROM employees
WHERE department='Sales'
AND hire_date BETWEEN '1990-01-01' AND '1999-12-31'
AND last_name LIKE 'S%';
