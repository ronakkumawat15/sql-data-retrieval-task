SELECT * FROM employees WHERE department='Sales' AND salary>50000;
SELECT * FROM employees WHERE department='Sales' OR department='Marketing';
