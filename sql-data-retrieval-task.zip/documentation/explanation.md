# Explanation

This project covers:
- SELECT
- WHERE
- ORDER BY
- LIMIT
- LIKE
- NULL handling

It demonstrates basic SQL data retrieval and filtering.
